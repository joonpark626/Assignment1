% Justin Park 101013156
% Assignment 1, Feb 6th, 2022
clear all;
close all;

global C
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                    % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass(kg)
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability
C.c = 299792458;                    % speed of light
C.g = 9.80665; %metres (32.1740 ft) per s²
C.am = 1.66053892e-27;

% Question 1: Electron Modeling
mn = 0.26*C.m_0; %Effective Mass
x_domain = 200e-9; % the length of the x domain
y_domain = 100e-9; % the length of the y domain
T = 300; % in Kelvin
nAtoms = 500;
nSteps = 1000;

V_th = sqrt(C.kb*T/mn);
time_mn = 0.2e-12; % mean time between collision (sec)

% -------------------------------------------------------------
% 2-1
% initialize random x and y velocities
rand_vel_x = randn(nAtoms,1)*sqrt(C.kb*T/mn);
rand_vel_y = randn(nAtoms,1)*sqrt(C.kb*T/mn);

v_avg = sqrt(rand_vel_x.^2 + rand_vel_y.^2);
%figure(1)
%plot(histo(v_avg, 100))

% -------------------------------------------------------------
%2-2
xr = 200e-9.*rand(nAtoms,1); %x of nAtoms random locations
yr = 100e-9.*rand(nAtoms,1); %y of nAtoms random locations

% Generate the initial location of the particles outside of rectangular blocks
xr(xr > 0.8e-7 & xr < 1e-7 & yr > 0.6e-7) = xr(xr > 0.8e-7 & xr < 1e-7 & yr > 0.6e-7) - 0.4e-7;
xr(xr > 1e-7 & xr < 1.2e-7 & yr > 0.6e-7) = xr(xr > 1e-7 & xr < 1.2e-7 & yr > 0.6e-7)  + 0.4e-7;
xr(xr > 0.8e-7 & xr < 1e-7 & yr < 0.4e-7) = xr(xr > 0.8e-7 & xr < 1e-7 & yr < 0.4e-7) - 0.4e-7;
xr(xr > 1e-7 & xr < 1.2e-7 & yr < 0.4e-7) = xr(xr > 1e-7 & xr < 1.2e-7 & yr < 0.4e-7)  + 0.4e-7;

% initialize the two vectors for previous x and y locations
prev_x = xr;
prev_y = yr;

% initialize the two vectors for mean free path x and y vectors
MFP_x = xr;
MFP_y = yr;

% initialize the two vectors for MFP and MTBC vectors
MFP = zeros(nAtoms,1); % MFP => Mean Free Path
MTBC = zeros(nAtoms,1); % MTBC => Mean Time Before Collision
scatter_num = zeros(nAtoms,1);

t = 1e-14; % time step size
delta_x = rand_vel_x*t; %distance in x during one time interval
delta_y = rand_vel_y*t; %distance isn y during one time interval
P_scatter = 1 - exp(-t/time_mn);

for p = 1:1:nSteps
    scatter_rand = rand(nAtoms,1);
    sr = scatter_rand;
    ps = P_scatter;
    % Calculate the Mean Free Path and Mean Time Between Collision of each step iteration
    MFP(sr < ps) = MFP(sr < ps) + sqrt((delta_x(sr < ps) - MFP_x(sr < ps)).^2 + (delta_y(sr < ps) - MFP_y(sr < ps)).^2);
    MTBC(sr < ps) = MTBC(sr < ps) + sqrt((delta_x(sr < ps) - MFP_x(sr < ps)).^2 + (delta_y(sr < ps) - MFP_y(sr < ps)).^2)./v_avg(sr < ps);
    scatter_num(sr < ps) = scatter_num(sr < ps) + 1;
    MFP_x(sr < ps) = xr(sr < ps);
    MFP_y(sr < ps) = yr(sr < ps);
    
    % Calculate the average temperature for the particles
    v_avg = sqrt(rand_vel_x.^2 + rand_vel_y.^2);
    temp_Particles = (0.5*mn*v_avg.^2)/C.kb;
    temp_avg (p) = sum(temp_Particles)/nAtoms;

    figure(2)
    plot(temp_avg)
    xlabel("Time")
    ylabel("Temperature")
    xlim([0, nSteps])
    ylim([0, 500])
    title("Temperature Map")
    
    % Calculate for the Mean Time Between Collision
    rand_vel_x_new = randn(nAtoms, 1)*sqrt(C.kb*T/mn);
    rand_vel_y_new = randn(nAtoms, 1)*sqrt(C.kb*T/mn);
    rand_vel_x(sr < ps) = rand_vel_x_new(sr < ps);
    rand_vel_y(sr < ps) = rand_vel_y_new(sr < ps);
    
    delta_x = rand_vel_x*t; %distance in x during one time interval
    delta_y = rand_vel_y*t; %distance in y during one time interval
    
    xr = xr + delta_x;
    yr = yr + delta_y;
    
    % Make the left and right walls
    % Right wall: Once penetrated, set the previous location on the wall,
    % then present x location to the opposite wall (Left)
    prev_x(xr >2e-7) = - (2e-7 - prev_x(xr >2e-7));
    xr(xr > 2e-7) = xr(xr > 2e-7)-(2e-7);
    
    % Left wall: Once penetrated, set the previous location on the wall,
    % then present x location to the opposite wall (Right)
    prev_x(xr <0) = 2e-7 - prev_x(xr <0);
    xr(xr < 0) = xr(xr < 0) + (2e-7);
    
    % Make the specular top&bottom walls
    % Top wall: Redirect towards down
    rand_vel_y(yr > 1e-7) = - rand_vel_y(yr > 1e-7);
    yr(yr > 1e-7) = (1e-7)-(yr(yr > 1e-7)-(1e-7));
    % Bottom wall: Redirect towards up
    rand_vel_y(yr < 0) = -rand_vel_y(yr < 0 );
    yr(yr < 0) = -yr(yr < 0);
    
    % Create the barricades
    % Left walls for the both blocks
    rand_vel_x(prev_x < 0.8e-7 & xr >= 0.8e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)) = - rand_vel_x(prev_x < 0.8e-7 & xr >= 0.8e-7 & (yr >= 0.6e-7 | yr < 0.4e-7));
    xr(prev_x < 0.8e-7 & xr >= 0.8e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)) = 0.8e-7 - (xr(prev_x < 0.8e-7 & xr >= 0.8e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)) - 0.8e-7);
    % Right walls for the both blocks
    rand_vel_x(prev_x > 1.2e-7 & xr <= 1.2e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)) = - rand_vel_x(prev_x > 1.2e-7 & xr <= 1.2e-7 & (yr >= 0.6e-7 | yr < 0.4e-7));
    xr(prev_x > 1.2e-7 & xr <= 1.2e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)) = 1.2e-7 + (1.2e-7 -  xr(prev_x > 1.2e-7 & xr <= 1.2e-7 & (yr >= 0.6e-7 | yr < 0.4e-7)));
    % Top walls for the both blocks
    rand_vel_y(prev_y < 0.6e-7 & yr >= 0.6e-7 & xr >= 0.8e-7 & xr <= 1.2e-7) = -rand_vel_y(prev_y < 0.6e-7 & yr >= 0.6e-7 & xr >= 0.8e-7 & xr <= 1.2e-7);
    yr(prev_y < 0.6e-7 & yr >= 0.6e-7 & xr >= 0.8e-7 & xr <= 1.2e-7) = 0.6e-7 - (yr(prev_y < 0.6e-7 & yr >= 0.6e-7 & xr >= 0.8e-7 & xr <= 1.2e-7) - 0.6e-7);
    % Bottom walls for the both blocks
    rand_vel_y(prev_y > 0.4e-7 & yr <= 0.4e-7 & xr >= 0.8e-7 & xr <= 1.2e-7) = -rand_vel_y(prev_y > 0.4e-7 & yr <= 0.4e-7 & xr >= 0.8e-7 & xr <= 1.2e-7);
    yr(prev_y > 0.4e-7 & yr <= 0.4e-7 & xr >= 0.8e-7 & xr <= 1.2e-7) = 0.4e-7 + (0.4e-7 - yr(prev_y > 0.4e-7 & yr <= 0.4e-7 & xr >= 0.8e-7 & xr <= 1.2e-7));
    
    
    figure (3)
    rectangle('Position', [0.8e-7 0 0.4e-7 0.4e-7])
    rectangle('Position', [0.8e-7 0.6e-7 0.4e-7 0.4e-7])
    plot([prev_x(1), xr(1)], [prev_y(1), yr(1)], 'r', [prev_x(2), xr(2)], [prev_y(2), yr(2)], 'g', [prev_x(3), xr(3)], [prev_y(3), yr(3)], 'b', [prev_x(4), xr(4)], [prev_y(4), yr(4)], 'c', [prev_x(5), xr(5)], [prev_y(5), yr(5)], 'm', [prev_x(6), xr(6)], [prev_y(6), yr(6)], 'y', [prev_x(7), xr(7)], [prev_y(7), yr(7)], 'k')

    xlabel("Semiconductor Length")
    ylabel("Semiconductor Width")
    title ("Particles Trajectory")
    xlim ([0, 2e-7])
    ylim([0,1e-7])
    grid on
    hold on
    pause(0.05)
    
    % The end of iteration, set the present location as the previous
    % location
    prev_x = xr;
    prev_y = yr;
end
% Calculate the total MFP and MTBC values
Total_MFP = sum(MFP./scatter_num)/nAtoms
Total_MTBC = sum(MTBC./scatter_num)/nAtoms

% Calculate an electron density map from the final electron positions
dimension = [xr,yr];
figure(4)
hist3(dimension)
xlabel("Horizontal")
ylabel("Vertical")
zlabel("Electron density")
title("Electron Density Map")
