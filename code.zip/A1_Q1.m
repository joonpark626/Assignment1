% Justin Park 101013156
% Assignment 1, Feb 6th, 2022
clear all;
close all

global C
C.q_0 = 1.60217653e-19;             % electron charge
C.hb = 1.054571596e-34;             % Dirac constant
C.h = C.hb * 2 * pi;                    % Planck constant
C.m_0 = 9.10938215e-31;             % electron mass(kg)
C.kb = 1.3806504e-23;               % Boltzmann constant
C.eps_0 = 8.854187817e-12;          % vacuum permittivity
C.mu_0 = 1.2566370614e-6;           % vacuum permeability
C.c = 299792458;                    % speed of light
C.g = 9.80665; %metres (32.1740 ft) per s²
C.am = 1.66053892e-27;

% Question 1: Electron Modeling
mn = 0.26*C.m_0; %Effective Mass
x_domain = 200e-9; % the length of the x domain
y_domain = 100e-9; % the length of the y domain
T = 300; % in Kelvin
nAtoms = 500;
nSteps = 500;

% -------------------------------------------------------------
% 1-1
% The thermal velocity at which the particles are travelling at
% Silicon atoms
V_th = sqrt(C.kb*T/mn)

% -------------------------------------------------------------
% 1-2
time_mn = 0.2e-12; % mean time between collision (sec)
mean_free_path = time_mn* V_th

% -------------------------------------------------------------
%1-3
xr = 200e-9.*rand(nAtoms,1); %x of nAtoms random locations
yr = 100e-9.*rand(nAtoms,1); %y of nAtoms random locations

% initialize the two vectors for previous x and y locations
prev_x = xr;
prev_y = yr;
angle = 2*pi.*rand(nAtoms,1); %angle in rad of 100 random locations
vel_x = cos(angle)*V_th; %initial horizontal velocity
vel_y = sin(angle)*V_th; %initial vertical veclocity

t = 1e-14; % time step size
delta_x = vel_x*t; %distance in x during one time interval
delta_y = vel_y*t; %distance in y during one time interval

for p = 1:1:nSteps
    
    % By each step(t interval), add the previous location with the distance
    % moved for an atom in a time interval
    xr = xr+delta_x;
    yr = yr+delta_y;
    
    % Calculate the average temperature of the all particles
    v = sqrt(vel_x.^2+vel_y.^2);
    temp_Particles = (mn*v.^2)/(C.kb);%Tempearture of individual particles
    temp_avg (p) = sum(temp_Particles)/nAtoms;%Average temperature of all particles
    figure (1)
    plot (temp_avg)
    xlim ([0, nSteps]) % Sets the x(min max)
    ylim ([0, 500])    % Sets the y(min max)
    xlabel("Time")
    ylabel("Temperature")
    title("Semiconductor temperature")
    
    % Make the left and right walls
    % Right wall: Once penetrated, set the previous location on the wall,
    % then present x location to the opposite wall (Left)
    prev_x(xr >2e-7) = - (2e-7 - prev_x(xr >2e-7));
    xr(xr > 2e-7) = xr(xr > 2e-7)-(2e-7);
    
    % Left wall: Once penetrated, set the previous location on the wall,
    % then present x location to the opposite wall (Right)
    prev_x(xr <0)    = 2e-7 - prev_x(xr <0);
    xr(xr < 0)    = xr(xr < 0 )+(2e-7);
    
    % Make the specular top&bottom walls
    % Top wall: Redirect towards down
    delta_y(yr > 1e-7) = - delta_y(yr > 1e-7);
    yr(yr > 1e-7) = (1e-7)-(yr(yr > 1e-7)-(1e-7));
    % Bottom wall: Redirect towards up
    delta_y(yr < 0) = -delta_y(yr < 0 );
    yr(yr < 0) = -yr(yr < 0);
    figure (2)
    plot([prev_x(1), xr(1)], [prev_y(1), yr(1)], 'r', [prev_x(2), xr(2)], [prev_y(2), yr(2)], 'g', [prev_x(3), xr(3)], [prev_y(3), yr(3)], 'b', [prev_x(4), xr(4)], [prev_y(4), yr(4)], 'c', [prev_x(5), xr(5)], [prev_y(5), yr(5)], 'm', [prev_x(6), xr(6)], [prev_y(6), yr(6)], 'y', [prev_x(7), xr(7)], [prev_y(7), yr(7)], 'k')

    xlabel("Semiconductor Length")
    ylabel("Semiconductor Width")
    title ("Particles Trajectory")
    xlim ([0, 2e-7])
    ylim([0,1e-7])
    grid on
    hold on
    pause(0.05)
    
    % The end of iteration, set the present location as the previous
    % location
    prev_x = xr;
    prev_y = yr;
end
